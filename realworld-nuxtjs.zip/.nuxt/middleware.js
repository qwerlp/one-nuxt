const middleware = {}

middleware['authenticated'] = require('../middleware/authenticated.js')
middleware['authenticated'] = middleware['authenticated'].default || middleware['authenticated']

middleware['notLogin'] = require('../middleware/notLogin.js')
middleware['notLogin'] = middleware['notLogin'].default || middleware['notLogin']

export default middleware
