import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _1026a24e = () => interopDefault(import('../pages/layout' /* webpackChunkName: "" */))
const _aa77d5fa = () => interopDefault(import('../pages/home' /* webpackChunkName: "" */))
const _a4125876 = () => interopDefault(import('../pages/login' /* webpackChunkName: "" */))
const _369071f6 = () => interopDefault(import('../pages/profile' /* webpackChunkName: "" */))
const _43812a47 = () => interopDefault(import('../pages/settings' /* webpackChunkName: "" */))
const _0457c891 = () => interopDefault(import('../pages/editor' /* webpackChunkName: "" */))
const _68fbeb5c = () => interopDefault(import('../pages/article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _1026a24e,
    children: [{
      path: "",
      component: _aa77d5fa,
      name: "home"
    }, {
      path: "/login",
      component: _a4125876,
      name: "login"
    }, {
      path: "/register",
      component: _a4125876,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _369071f6,
      name: "profile"
    }, {
      path: "/settings",
      component: _43812a47,
      name: "settings"
    }, {
      path: "/editor",
      component: _0457c891,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _68fbeb5c,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
